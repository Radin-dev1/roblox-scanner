# Roblox Avatar Scanner

Type a Roblox username and it pulls **every detail** of the avatar:

- Every worn item (name, type, asset ID) with thumbnails
- Body colors and proportions/scales
- The **real 3D model** Roblox generates — viewable in-browser and downloadable as `.obj` / `.mtl` / textures (open it in Blender!)
- A **style brain** that learns from every avatar you scan — no API key, no sign-up

## The "AI that trains itself"

There's no giant pre-trained model and no API key. Instead, a small model lives in
`data/brain.json` and **learns from each scan**:

- **Rarity** — how often it's seen each item across everything you've scanned
- **"Also wears"** — item co-occurrence ("people who wore X also wore Y"), learned purely from data, nothing hardcoded
- **Vibe** — an aesthetic guess that sharpens as the data grows

Scan 2 avatars and it's clueless. Scan 200 and the rarity scores and suggestions
get genuinely useful. That's the real version of "trains itself": it improves on
its own as it gets more data.

> Want to wipe what it learned and start fresh? `POST /api/brain/reset`
> (or just delete `data/brain.json`).

## Run it

You need [Node.js](https://nodejs.org) version 18 or newer.

```bash
npm install
npm start
```

Then open **http://localhost:3000** and scan an avatar (try `Roblox` or `builderman`).

## Why a backend?

A browser can't call Roblox's API directly (it gets blocked). The backend makes
those calls for you, and also proxies the 3D model files so they load cleanly.

## How it works

```
public/index.html · styles.css · app.js   → the scanner UI
server.js                                  → talks to Roblox + runs the brain
data/brain.json                            → what the model has learned (auto-created)
```

Roblox endpoints used (all public):
`users.roblox.com` (username → id), `avatar.roblox.com` (worn items, colors, scales),
`thumbnails.roblox.com` (avatar + item images, and the 3D model).

## Ideas to extend

- A "compare two avatars" mode
- Export a scan as a PNG report card
- Track each item's rarity trend over time
- Let the brain group avatars into clusters (k-means on item vectors)
