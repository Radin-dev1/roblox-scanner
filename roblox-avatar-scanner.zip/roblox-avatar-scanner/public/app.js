// app.js — talks to our own backend (same origin), renders results,
// loads the 3D model on demand, and stores bookmarks locally.

const $ = (id) => document.getElementById(id);
let lastScan = null;

// ---------------------------------------------------------------------------
// Brain stat in the header
async function refreshBrain() {
  try {
    const b = await fetch("/api/brain").then((r) => r.json());
    $("brainStatText").textContent = `brain: ${b.totalScans} scans · ${b.itemsKnown} items`;
  } catch {
    $("brainStatText").textContent = "brain: offline";
  }
}

// ---------------------------------------------------------------------------
// Scan
async function scan(name) {
  if (!name) return;
  const btn = $("scanBtn");
  btn.disabled = true;
  btn.textContent = "Scanning…";
  $("error").classList.add("hidden");
  $("stage").classList.remove("hidden");
  document.querySelector(".scan-frame").classList.add("scanning");
  $("avatarImg").removeAttribute("src");

  try {
    const data = await fetch(`/api/scan?username=${encodeURIComponent(name)}`).then((r) => r.json());
    if (data.error) throw new Error(data.error);
    lastScan = data;
    render(data);
    refreshBrain();
  } catch (err) {
    showError(err.message);
    $("stage").classList.add("hidden");
  } finally {
    btn.disabled = false;
    btn.textContent = "Scan";
    document.querySelector(".scan-frame").classList.remove("scanning");
  }
}

function showError(msg) {
  const e = $("error");
  e.textContent = `Couldn't scan that. ${msg}`;
  e.classList.remove("hidden");
}

// ---------------------------------------------------------------------------
// Render everything
function render(d) {
  if (d.avatarThumb) $("avatarImg").src = d.avatarThumb;
  $("idName").textContent = d.user.displayName || d.user.name;
  $("idHandle").textContent = `@${d.user.name} · id ${d.user.id}`;
  $("idType").textContent = d.playerAvatarType || "R15";

  // vibe + suggestions
  $("vibe").textContent = d.report.vibe;
  $("vibeNote").textContent =
    d.report.brain.totalScans < 5
      ? `The brain has only seen ${d.report.brain.totalScans} avatar(s). Scan more and rarity + suggestions sharpen up.`
      : `Trained on ${d.report.brain.totalScans} avatars · ${d.report.brain.itemsKnown} items known.`;

  const sug = $("suggest");
  sug.innerHTML = "";
  if (!d.report.suggestions.length) {
    sug.innerHTML = `<li class="muted">No suggestions yet — scan more avatars to train them.</li>`;
  } else {
    for (const s of d.report.suggestions) {
      const li = document.createElement("li");
      li.innerHTML = `<span>${esc(s.name)}</span><span class="s-type">${esc(s.type)}</span>`;
      sug.appendChild(li);
    }
  }

  // body colors
  const sw = $("swatches");
  sw.innerHTML = "";
  for (const [key, val] of Object.entries(d.bodyColors || {})) {
    const hex = colorToHex(val);
    const div = document.createElement("div");
    div.className = "swatch";
    div.innerHTML = `<b style="background:${hex || "#444"}"></b>${key.replace("ColorId", "")}: ${val}`;
    sw.appendChild(div);
  }

  // proportions
  const bars = $("bars");
  bars.innerHTML = "";
  for (const [key, val] of Object.entries(d.scales || {})) {
    const pct = Math.max(0, Math.min(100, Number(val) * 70));
    const row = document.createElement("div");
    row.className = "bar-row";
    row.innerHTML = `<span class="b-label">${key}</span><div class="bar-track"><div class="bar-fill" style="width:${pct}%"></div></div><span class="b-val">${Number(val).toFixed(2)}</span>`;
    bars.appendChild(row);
  }

  // items
  $("itemCount").textContent = `(${d.assets.length})`;
  const items = $("items");
  items.innerHTML = "";
  for (const a of d.report.items) {
    const thumb = d.itemThumbs[a.id] || "";
    const tierTxt = a.pct == null ? "new" : a.tier;
    const div = document.createElement("div");
    div.className = "item";
    div.innerHTML = `
      <span class="tier ${a.tier}">${tierTxt}</span>
      <img src="${thumb}" alt="${esc(a.name)}" loading="lazy" />
      <div class="i-name">${esc(a.name)}</div>
      <div class="i-type">${esc(a.type)}</div>
      <div class="i-id">#${a.id}</div>`;
    items.appendChild(div);
  }

  // reset 3d panel
  $("viewer").innerHTML = `<span class="viewer-hint">Roblox renders a real 3D model of this avatar. Click “Load 3D”.</span>`;
  $("downloads").classList.add("hidden");
  $("downloads").innerHTML = "";

  // bookmark button state
  const saved = getBookmarks().some((b) => b.id === d.user.id);
  const sb = $("saveBtn");
  sb.classList.toggle("saved", saved);
  sb.textContent = saved ? "★ Bookmarked" : "☆ Bookmark";
}

// Roblox bodyColors are BrickColor IDs. We map a few of the most common ones;
// anything unknown still shows its ID, just without a perfect swatch.
const BRICK_HEX = {
  1: "#f2f3f3", 21: "#c4281c", 23: "#0d69ac", 24: "#f5cd30", 26: "#1b2a35",
  37: "#4b974b", 102: "#6c99c8", 105: "#e29b40", 119: "#a4bd47", 199: "#635f62",
  208: "#e5e4df", 1001: "#f8f8f8", 9: "#f7d0a5", 18: "#cc8e69", 125: "#eab892",
};
function colorToHex(v) {
  if (typeof v === "string" && v.startsWith("#")) return v;
  return BRICK_HEX[v] || null;
}

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));

// ---------------------------------------------------------------------------
// 3D viewer — lazy-loads three.js only when asked
let threeReady = false;
function loadScript(src) {
  return new Promise((res, rej) => {
    const s = document.createElement("script");
    s.src = src; s.onload = res; s.onerror = () => rej(new Error("script load failed"));
    document.head.appendChild(s);
  });
}
async function ensureThree() {
  if (threeReady) return;
  const u = window.THREE_URLS;
  await loadScript(u.three);
  await Promise.all([loadScript(u.mtl), loadScript(u.obj), loadScript(u.orbit)]);
  threeReady = true;
}

async function load3D() {
  if (!lastScan) return;
  const btn = $("load3d");
  btn.disabled = true; btn.textContent = "Loading…";
  const viewer = $("viewer");
  viewer.innerHTML = `<span class="viewer-hint">Fetching model from Roblox…</span>`;
  try {
    const meta = await fetch(`/api/avatar-3d/${lastScan.user.id}`).then((r) => r.json());
    if (meta.error) throw new Error(meta.error);
    await ensureThree();
    renderModel(meta);
    showDownloads(meta);
  } catch (err) {
    viewer.innerHTML = `<span class="viewer-hint">3D didn't load: ${esc(err.message)}</span>`;
  } finally {
    btn.disabled = false; btn.textContent = "Load 3D";
  }
}

function renderModel(meta) {
  const viewer = $("viewer");
  viewer.innerHTML = "";
  const w = viewer.clientWidth, h = viewer.clientHeight;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(45, w / h, 0.1, 5000);
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
  renderer.setSize(w, h);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
  viewer.appendChild(renderer.domElement);

  scene.add(new THREE.AmbientLight(0xffffff, 0.9));
  const key = new THREE.DirectionalLight(0xffffff, 0.8);
  key.position.set(1, 2, 2); scene.add(key);

  const controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.enableDamping = true;

  const mtlLoader = new THREE.MTLLoader();
  mtlLoader.setPath("/api/cdn/");
  // meta.mtlUrl is "/api/cdn/<hash>" — strip the path so the loader resolves
  // textures (also /api/cdn/<hash>) relative to the same base.
  const mtlName = meta.mtlUrl.split("/").pop();
  mtlLoader.load(mtlName, (materials) => {
    materials.preload();
    const objLoader = new THREE.OBJLoader();
    objLoader.setMaterials(materials);
    objLoader.setPath("/api/cdn/");
    objLoader.load(meta.objUrl.split("/").pop(), (obj) => {
      // center + frame the model
      const box = new THREE.Box3().setFromObject(obj);
      const center = box.getCenter(new THREE.Vector3());
      const size = box.getSize(new THREE.Vector3());
      obj.position.sub(center);
      scene.add(obj);
      const radius = Math.max(size.x, size.y, size.z);
      camera.position.set(0, 0, radius * 2.4);
      controls.update();
    });
  });

  (function animate() {
    requestAnimationFrame(animate);
    controls.update();
    renderer.render(scene, camera);
  })();

  window.addEventListener("resize", () => {
    const nw = viewer.clientWidth, nh = viewer.clientHeight;
    camera.aspect = nw / nh; camera.updateProjectionMatrix(); renderer.setSize(nw, nh);
  });
}

function showDownloads(meta) {
  const d = $("downloads");
  d.classList.remove("hidden");
  d.innerHTML =
    `<a href="${meta.objUrl}" download="avatar.obj">⬇ avatar.obj</a>` +
    `<a href="${meta.mtlUrl}" download="avatar.mtl">⬇ avatar.mtl</a>` +
    meta.textureUrls.map((u, i) => `<a href="${u}" download="texture${i}.png">⬇ texture ${i}</a>`).join("");
}

// ---------------------------------------------------------------------------
// Bookmarks (localStorage — your own site, so this is fine and persists)
function getBookmarks() {
  try { return JSON.parse(localStorage.getItem("scanner_bookmarks") || "[]"); } catch { return []; }
}
function setBookmarks(list) {
  localStorage.setItem("scanner_bookmarks", JSON.stringify(list));
  renderBookmarks();
}
function toggleBookmark() {
  if (!lastScan) return;
  const list = getBookmarks();
  const i = list.findIndex((b) => b.id === lastScan.user.id);
  if (i >= 0) list.splice(i, 1);
  else list.unshift({ id: lastScan.user.id, name: lastScan.user.name, thumb: lastScan.avatarThumb });
  setBookmarks(list);
  const saved = i < 0;
  $("saveBtn").classList.toggle("saved", saved);
  $("saveBtn").textContent = saved ? "★ Bookmarked" : "☆ Bookmark";
}
function renderBookmarks() {
  const list = getBookmarks();
  const sec = $("bookmarks");
  const grid = $("bmGrid");
  sec.classList.toggle("hidden", list.length === 0);
  grid.innerHTML = "";
  for (const b of list) {
    const div = document.createElement("div");
    div.className = "bm";
    div.innerHTML = `<img src="${b.thumb || ""}" alt="${esc(b.name)}" /><div class="bm-name">@${esc(b.name)}</div>`;
    div.onclick = () => { $("username").value = b.name; scan(b.name); window.scrollTo({ top: 0, behavior: "smooth" }); };
    grid.appendChild(div);
  }
}

// ---------------------------------------------------------------------------
// Wire up
$("scanBtn").onclick = () => scan($("username").value);
$("username").addEventListener("keydown", (e) => { if (e.key === "Enter") scan($("username").value); });
$("saveBtn").onclick = toggleBookmark;
$("load3d").onclick = load3D;
document.querySelectorAll(".example").forEach((b) =>
  b.addEventListener("click", () => { $("username").value = b.dataset.name; scan(b.dataset.name); })
);

refreshBrain();
renderBookmarks();
