// server.js — Roblox Avatar Scanner backend
// Runs on Node 18+ (uses built-in fetch). No API key required.
//
// What it does:
//  1. Talks to Roblox's public APIs from the server (browsers can't, so we do it here).
//  2. Keeps a "brain" (data/brain.json) that LEARNS from every avatar you scan:
//     item rarity, item co-occurrence ("also wore"), and color frequency.
//     The more avatars you scan, the smarter the rarity + suggestions get.
//  3. Pulls the real 3D model Roblox generates for an avatar and proxies the files
//     so the browser can load them with no CORS problems.

import express from "express";
import { fileURLToPath } from "url";
import { dirname, join } from "path";
import { readFile, writeFile, mkdir } from "fs/promises";

const __dirname = dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static(join(__dirname, "public")));

// A normal User-Agent keeps Roblox happy.
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36";

async function robloxGet(url) {
  const res = await fetch(url, { headers: { "User-Agent": UA, Accept: "application/json" } });
  if (!res.ok) throw new Error(`Roblox ${res.status} for ${url}`);
  return res.json();
}

// ---------------------------------------------------------------------------
// THE BRAIN  — a tiny model that trains itself on the avatars you scan.
// ---------------------------------------------------------------------------
const BRAIN_PATH = join(__dirname, "data", "brain.json");

// A small starter lexicon. The DATA refines the vibe over time, but this gives
// the model a few words to start with on day one. Keys are matched against
// item names (lowercase, "contains").
const VIBE_LEXICON = {
  premium: ["korblox", "headless", "valkyrie", "dominus", "sparkle time", "antlers"],
  emo: ["slender", "emo", "chain", "skull", "spike", "black", "y2k", "scene"],
  cute: ["cute", "pastel", "bow", "kawaii", "bunny", "heart", "fairy", "angel"],
  streetwear: ["hoodie", "cargo", "sneaker", "beanie", "puffer", "drip", "street"],
  fantasy: ["wizard", "knight", "dragon", "elf", "wings", "mage", "crown", "sword"],
  robot: ["robot", "mech", "cyber", "neon", "tech", "bot", "circuit"],
};

const emptyBrain = () => ({
  version: 1,
  totalScans: 0,
  items: {}, // assetId -> { name, type, count }
  cowear: {}, // assetId -> { otherAssetId: count }
  colors: {}, // colorKey -> count
  lastUpdated: null,
});

async function loadBrain() {
  try {
    return JSON.parse(await readFile(BRAIN_PATH, "utf8"));
  } catch {
    return emptyBrain();
  }
}

async function saveBrain(brain) {
  brain.lastUpdated = new Date().toISOString();
  await mkdir(dirname(BRAIN_PATH), { recursive: true });
  await writeFile(BRAIN_PATH, JSON.stringify(brain, null, 2));
}

// This is the "training" step. It runs automatically on every scan.
function learnFromAvatar(brain, assets, colorKeys) {
  brain.totalScans += 1;

  const ids = assets.map((a) => String(a.id));

  for (const a of assets) {
    const id = String(a.id);
    const entry = brain.items[id] || { name: a.name, type: a.type, count: 0 };
    entry.name = a.name;
    entry.type = a.type;
    entry.count += 1;
    brain.items[id] = entry;
  }

  // Co-occurrence: every pair of items worn together gets a +1. This is what
  // powers "people who wore X also wore Y" — purely learned, nothing hardcoded.
  for (let i = 0; i < ids.length; i++) {
    for (let j = i + 1; j < ids.length; j++) {
      const a = ids[i];
      const b = ids[j];
      (brain.cowear[a] ||= {})[b] = (brain.cowear[a][b] || 0) + 1;
      (brain.cowear[b] ||= {})[a] = (brain.cowear[b][a] || 0) + 1;
    }
  }

  for (const c of colorKeys) {
    brain.colors[c] = (brain.colors[c] || 0) + 1;
  }
}

// Turn raw counts into a human label. With little data everything looks rare,
// so the label is honest about how much the brain has actually seen.
function rarityLabel(count, totalScans) {
  if (totalScans < 5) return { tier: "learning", pct: null };
  const pct = count / totalScans;
  if (pct >= 0.5) return { tier: "common", pct };
  if (pct >= 0.2) return { tier: "uncommon", pct };
  if (pct >= 0.05) return { tier: "rare", pct };
  return { tier: "legendary", pct };
}

function buildReport(brain, assets) {
  const wornIds = new Set(assets.map((a) => String(a.id)));

  // Rarity per worn item.
  const items = assets.map((a) => {
    const id = String(a.id);
    const count = brain.items[id]?.count || 0;
    return { ...a, seen: count, ...rarityLabel(count, brain.totalScans) };
  });

  // Suggestions: add up co-occurrence scores from everything this avatar wears,
  // then recommend the highest-scoring items they DON'T already have.
  const scores = {};
  for (const id of wornIds) {
    const co = brain.cowear[id] || {};
    for (const [other, n] of Object.entries(co)) {
      if (wornIds.has(other)) continue;
      scores[other] = (scores[other] || 0) + n;
    }
  }
  const suggestions = Object.entries(scores)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([id, score]) => ({
      id: Number(id),
      name: brain.items[id]?.name || `Item ${id}`,
      type: brain.items[id]?.type || "Unknown",
      score,
    }));

  // Vibe: lexicon hits, weighted slightly by how popular each matched item is.
  const tagScores = {};
  for (const a of assets) {
    const lname = (a.name || "").toLowerCase();
    const popularity = 1 + (brain.items[String(a.id)]?.count || 0) / Math.max(1, brain.totalScans);
    for (const [tag, words] of Object.entries(VIBE_LEXICON)) {
      if (words.some((w) => lname.includes(w))) tagScores[tag] = (tagScores[tag] || 0) + popularity;
    }
  }
  const topTags = Object.entries(tagScores)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2)
    .map(([t]) => t);
  const vibe = topTags.length ? topTags.join(" + ") : "undefined (scan more avatars to teach the brain)";

  return {
    items,
    suggestions,
    vibe,
    brain: {
      totalScans: brain.totalScans,
      itemsKnown: Object.keys(brain.items).length,
    },
  };
}

// ---------------------------------------------------------------------------
// ROUTES
// ---------------------------------------------------------------------------

// Resolve a username to a numeric userId (or accept a numeric id directly).
async function resolveUserId(input) {
  const trimmed = String(input).trim();
  if (/^\d+$/.test(trimmed)) return Number(trimmed);
  const res = await fetch("https://users.roblox.com/v1/usernames/users", {
    method: "POST",
    headers: { "Content-Type": "application/json", "User-Agent": UA },
    body: JSON.stringify({ usernames: [trimmed], excludeBannedUsers: false }),
  });
  if (!res.ok) throw new Error(`username lookup failed (${res.status})`);
  const json = await res.json();
  if (!json.data || !json.data.length) throw new Error("no user with that name");
  return json.data[0].id;
}

// Main scan: returns identity, full avatar data, item thumbnails, and the
// self-learned report.
app.get("/api/scan", async (req, res) => {
  try {
    const q = req.query.username;
    if (!q) return res.status(400).json({ error: "Add ?username=SomeName" });

    const userId = await resolveUserId(q);

    const [userInfo, avatar, thumb] = await Promise.all([
      robloxGet(`https://users.roblox.com/v1/users/${userId}`),
      robloxGet(`https://avatar.roblox.com/v1/users/${userId}/avatar`),
      robloxGet(
        `https://thumbnails.roblox.com/v1/users/avatar?userIds=${userId}&size=420x420&format=Png&isCircular=false`
      ),
    ]);

    const assets = (avatar.assets || []).map((a) => ({
      id: a.id,
      name: a.name,
      type: a.assetType?.name || "Unknown",
    }));

    // Per-item thumbnails (batched).
    let itemThumbs = {};
    if (assets.length) {
      const ids = assets.map((a) => a.id).join(",");
      const t = await robloxGet(
        `https://thumbnails.roblox.com/v1/assets?assetIds=${ids}&size=150x150&format=Png&isCircular=false`
      );
      for (const d of t.data || []) itemThumbs[d.targetId] = d.imageUrl;
    }

    const colorKeys = Object.values(avatar.bodyColors || {}).map(String);

    // ---- TRAIN ----
    const brain = await loadBrain();
    learnFromAvatar(brain, assets, colorKeys);
    const report = buildReport(brain, assets);
    await saveBrain(brain);

    res.json({
      user: { id: userId, name: userInfo.name, displayName: userInfo.displayName },
      avatarThumb: thumb.data?.[0]?.imageUrl || null,
      playerAvatarType: avatar.playerAvatarType,
      scales: avatar.scales || {},
      bodyColors: avatar.bodyColors || {},
      assets,
      itemThumbs,
      report,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 3D model metadata: poll Roblox until the model is ready, then hand back the
// file hashes (proxied through /api/cdn so the browser can fetch them).
app.get("/api/avatar-3d/:userId", async (req, res) => {
  try {
    const userId = req.params.userId;
    let meta = null;
    for (let attempt = 0; attempt < 6; attempt++) {
      const json = await robloxGet(
        `https://thumbnails.roblox.com/v1/users/avatar-3d?userId=${userId}`
      );
      const obj = Array.isArray(json.data) ? json.data[0] : json;
      if (obj?.state === "Completed" && obj.imageUrl) {
        meta = obj;
        break;
      }
      await new Promise((r) => setTimeout(r, 800));
    }
    if (!meta) return res.status(202).json({ error: "Model still rendering, try again." });

    const model = await robloxGet(meta.imageUrl); // { obj, mtl, textures, camera, aabb }
    res.json({
      objUrl: `/api/cdn/${model.obj}`,
      mtlUrl: `/api/cdn/${model.mtl}`,
      textureUrls: (model.textures || []).map((h) => `/api/cdn/${h}`),
      camera: model.camera,
      aabb: model.aabb,
      hashes: { obj: model.obj, mtl: model.mtl, textures: model.textures },
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Stream a Roblox CDN file by its hash, trying each mirror. Sniffs PNG so
// textures get the right content type; obj/mtl come back as plain bytes.
app.get("/api/cdn/:hash", async (req, res) => {
  const hash = req.params.hash;
  for (let n = 0; n <= 7; n++) {
    try {
      const r = await fetch(`https://t${n}.rbxcdn.com/${hash}`, { headers: { "User-Agent": UA } });
      if (!r.ok) continue;
      const buf = Buffer.from(await r.arrayBuffer());
      const isPng = buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47;
      res.setHeader("Content-Type", isPng ? "image/png" : "application/octet-stream");
      res.setHeader("Cache-Control", "public, max-age=86400");
      return res.send(buf);
    } catch {
      /* try next mirror */
    }
  }
  res.status(404).json({ error: "file not found on any CDN mirror" });
});

// Inspect or reset the brain.
app.get("/api/brain", async (_req, res) => {
  const brain = await loadBrain();
  res.json({
    totalScans: brain.totalScans,
    itemsKnown: Object.keys(brain.items).length,
    lastUpdated: brain.lastUpdated,
  });
});

app.post("/api/brain/reset", async (_req, res) => {
  await saveBrain(emptyBrain());
  res.json({ ok: true });
});

app.listen(PORT, () => {
  console.log(`\n  Roblox Avatar Scanner running:  http://localhost:${PORT}\n`);
});
